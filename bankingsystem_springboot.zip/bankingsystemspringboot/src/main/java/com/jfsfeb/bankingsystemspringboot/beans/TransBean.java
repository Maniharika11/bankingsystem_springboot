package com.jfsfeb.bankingsystemspringboot.beans;

import lombok.Data;

@Data
public class TransBean {

	// data member
	private int fromAccountId;
	private int toAccountId;
	private double amount;
	private String transType;
	
}
