package com.jfsfeb.bankingsystemspringboot.beans;

import lombok.Data;

@Data
public class LoginBean {

	private int accountId;

	private String loginPassword;

}
