package com.jfsfeb.bankingsystemspringboot.beans;

import java.util.List;

import lombok.Data;

@Data
public class UserResponse {

	private int statusCode;
	private String message;
	private String description;
	private UserTrackerBean userTrackerBean;
	private List<TransactionBean> tBean;
	private List<ServiceTrackerBean> checkBookList;
	private TransactionBean tranBean;
	private List<UserTrackerBean> uBean;
	
}
