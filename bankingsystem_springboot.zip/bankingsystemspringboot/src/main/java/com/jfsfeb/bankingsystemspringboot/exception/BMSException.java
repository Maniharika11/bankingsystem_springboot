package com.jfsfeb.bankingsystemspringboot.exception;

@SuppressWarnings("serial")
public class BMSException extends RuntimeException {
	
	public BMSException(String msg) {
		super(msg);
	}

}
