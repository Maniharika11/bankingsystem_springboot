package com.jfsfeb.bankingsystemspringboot.dao;

import java.util.List;

import com.jfsfeb.bankingsystemspringboot.beans.LoginBean;
import com.jfsfeb.bankingsystemspringboot.beans.ServiceTrackerBean;
import com.jfsfeb.bankingsystemspringboot.beans.TransBean;
import com.jfsfeb.bankingsystemspringboot.beans.TransactionBean;
import com.jfsfeb.bankingsystemspringboot.beans.UserTrackerBean;

public interface BankDao {
	
	public UserTrackerBean login(LoginBean loginBean);

	public boolean addUser(UserTrackerBean userTrackerBean);

	public boolean updateUser(UserTrackerBean updateDetail);

	public TransactionBean doTransaction(TransBean transBean);

	public List<TransactionBean> getAllTransactions(int accountId);

	public List<UserTrackerBean> getAllDetails();

	public List<TransactionBean> getAllTransactions();

	public boolean checkBookRequest(ServiceTrackerBean serviceTrackerBean);

	public List<ServiceTrackerBean> getAllcheckBookRequest();

}
