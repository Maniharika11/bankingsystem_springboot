package com.jfsfeb.bankingsystemspringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jfsfeb.bankingsystemspringboot.beans.LoginBean;
import com.jfsfeb.bankingsystemspringboot.beans.ServiceTrackerBean;
import com.jfsfeb.bankingsystemspringboot.beans.TransBean;
import com.jfsfeb.bankingsystemspringboot.beans.TransactionBean;
import com.jfsfeb.bankingsystemspringboot.beans.UserResponse;
import com.jfsfeb.bankingsystemspringboot.beans.UserTrackerBean;
import com.jfsfeb.bankingsystemspringboot.service.BankService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class BankController {

	@Autowired
	private BankService service;

	@PostMapping("/login")
	public UserResponse login(@RequestBody LoginBean loginBean, ModelMap modelMap) {
		UserTrackerBean userBean = service.login(loginBean);
		modelMap.addAttribute("userBean", userBean);
		UserResponse userResponse = new UserResponse();

		if (userBean != null) {
			userResponse.setStatusCode(401);
			userResponse.setMessage("User LoggedIn successfully");
			userResponse.setDescription("User record Found");
			userResponse.setUserTrackerBean(userBean);

		} else {
			userResponse.setStatusCode(402);
			userResponse.setMessage("failed");
			userResponse.setDescription("Sorry, invalid credentials");
		}
		return userResponse;

	}// end of login()

	@PostMapping(path = "/addUser")
	public UserResponse addUser(@RequestBody UserTrackerBean customerBean) {
		boolean isAdded = service.addUser(customerBean);

		UserResponse response = new UserResponse();
		if (isAdded) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("Successfully Added");
		} else {
			response.setStatusCode(402);
			response.setMessage("Failed");
			response.setDescription("Unable to add User");
		}
		return response;

	}// end of addUser()
	
	@GetMapping(path = "/getTransaction")
	public UserResponse getAllTransactions() {
		List<TransactionBean> tranBean = service.getAllTransactions();
		UserResponse response = new UserResponse();

		if (tranBean != null) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("Your All Transaction ");
			response.setTBean(tranBean);

		} else {
			response.setStatusCode(402);
			response.setMessage("Fail");
			response.setDescription("Sorry no transaction is found for user!! ");
		}

		return response;
	}// end of getTransaction
	
	@GetMapping(path = "/getAllDetails")
	public UserResponse getAllDetails() {
		List<UserTrackerBean> tranBean = service.getAllDetails();
		UserResponse response = new UserResponse();

		if (tranBean != null) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("All User Details");
			response.setUBean(tranBean);

		} else {
			response.setStatusCode(402);
			response.setMessage("Fail");
			response.setDescription("Sorry no Users are found!!");
		}

		return response;
	}// end of getDetails
	
	@PutMapping(path = "/updateUser")
	public UserResponse updateUser(@RequestBody UserTrackerBean updateDetail) {

		boolean isUpdated = service.updateUser(updateDetail);
		UserResponse response = new UserResponse();
		if (isUpdated) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("Successfully Updated");
		} else {
			response.setStatusCode(402);
			response.setMessage("Failed");
			response.setDescription("Unable to Update");
		}

		return response;

	}

	@PostMapping(path = "/transaction")
	public UserResponse doTansaction(@RequestBody TransBean transBean, ModelMap modelMap) {
		TransactionBean isTransfer = service.doTransaction(transBean);
		modelMap.addAttribute("isTransfer", isTransfer);
		UserResponse response = new UserResponse();
		if (isTransfer != null) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("Transction successfull");
			response.setTranBean(isTransfer);

		} else {
			response.setStatusCode(402);
			response.setMessage("Failed");
			response.setDescription("Something went wrong");
		}
		return response;
	}// end of transaction()

	@GetMapping(path = "/getAllTransaction")
	public List<TransactionBean> getAlltransactions(@RequestParam("accountId") int accountId) {
		List<TransactionBean> tranBean = service.getAllTransactions(accountId);
		UserResponse response = new UserResponse();

		if (tranBean != null) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("Your All Transaction ");
			response.setTBean(tranBean);

		} else {
			response.setStatusCode(402);
			response.setMessage("Fail");
			response.setDescription("Sorry no transaction is found for user!! ");
		}

		return tranBean;
	}// end of getAlltransaction
	
	@PostMapping(path = "/checkBookRequest")
	public UserResponse checkBookRequest(@RequestBody ServiceTrackerBean serviceTracker) {
		boolean isAdded = service.checkBookRequest(serviceTracker);
		UserResponse response = new UserResponse();
		if (isAdded) {
			response.setStatusCode(401);
			response.setMessage("Success");
			response.setDescription("Check book request accepted");

		} else {
			response.setStatusCode(402);
			response.setMessage("failed");
			response.setDescription("Something went wrong");

		}
		return response;

	}// end of checkBookRequest

	@GetMapping(path = "/getAllCheckBookRequest")
	public UserResponse getAllCheckBookRequest() {

		List<ServiceTrackerBean> requestList = service.getAllcheckBookRequest();
		UserResponse response = new UserResponse();
		if (requestList != null) {
			response.setStatusCode(401);
			response.setMessage("success");
			response.setCheckBookList(requestList);

		} else {
			{
				response.setStatusCode(402);
				response.setMessage("no request available");
			}

		}
		return response;

	}// end of getAllchequeBookList

}
