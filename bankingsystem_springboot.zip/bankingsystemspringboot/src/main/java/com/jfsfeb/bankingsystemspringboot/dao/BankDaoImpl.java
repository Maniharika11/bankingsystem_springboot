package com.jfsfeb.bankingsystemspringboot.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;

import com.jfsfeb.bankingsystemspringboot.beans.LoginBean;
import com.jfsfeb.bankingsystemspringboot.beans.ServiceTrackerBean;
import com.jfsfeb.bankingsystemspringboot.beans.TransBean;
import com.jfsfeb.bankingsystemspringboot.beans.TransactionBean;
import com.jfsfeb.bankingsystemspringboot.beans.UserTrackerBean;
import com.jfsfeb.bankingsystemspringboot.exception.BMSException;

@Repository
public class BankDaoImpl implements BankDao {

	@PersistenceUnit
	private EntityManagerFactory emf;

	@Override
	public UserTrackerBean login(LoginBean loginBean) {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from UserTrackerBean where Account_Id =:accid and Login_Password =:pwd";
		Query query = manager.createQuery(jpql);
		query.setParameter("accid", loginBean.getAccountId());
		query.setParameter("pwd", loginBean.getLoginPassword());
		UserTrackerBean userBean = null;
		try {
			userBean = (UserTrackerBean) query.getSingleResult();
			if (userBean.getPassword().equals(loginBean.getLoginPassword())) {
				return userBean;
			}
		} catch (Exception e) {
			throw new BMSException("Invalid User name or Password");
		}
		manager.close();

		return null;
	}

	@Override
	public boolean addUser(UserTrackerBean userTrackerBean) {

		EntityManager manager = emf.createEntityManager();
		EntityTransaction ts = manager.getTransaction();
		boolean isAdded = false;

		try {
			ts.begin();
			manager.persist(userTrackerBean);
			isAdded = true;
			ts.commit();

		} catch (Exception e) {
			throw new BMSException("This id is alredy exist. Please try with another id");
		}
		manager.close();

		return isAdded;
	}// end of addUser()

	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionBean> getAllTransactions() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from TransactionBean";
		Query query = manager.createQuery(jpql);
		List<TransactionBean> transList = null;
		try {
			transList = query.getResultList();
		} catch (Exception e) {
			throw new BMSException("No Transactions are Available Here");
		}

		return transList;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserTrackerBean> getAllDetails() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from UserTrackerBean where userType='user'";
		Query query = manager.createQuery(jpql);
		List<UserTrackerBean> bean = null;
		try {
			bean = query.getResultList();
		} catch (Exception e) {
			throw new BMSException("No Users are Available Here");
		}
		return bean;
	}

	@Override
	public boolean updateUser(UserTrackerBean updateDetail) {
		EntityManager em = emf.createEntityManager();
		UserTrackerBean custmBean = em.find(UserTrackerBean.class, updateDetail.getAccountId());
		boolean isUpdated = false;
		if (custmBean != null) {

			String email = updateDetail.getEmail();
			if (email != null) {
				custmBean.setEmail(email);
			}

			long phone = updateDetail.getPhone();
			if (phone != 0) {
				custmBean.setPhone(phone);
			}

			String password = updateDetail.getPassword();
			if (password != null) {
				custmBean.setPassword(password);
			}

			try {
				EntityTransaction tx = em.getTransaction();
				tx.begin();
				em.persist(custmBean);
				tx.commit();
				isUpdated = true;
			} catch (Exception e) {
				throw new BMSException("Unable to Update");
			}
			em.close();
		}
		return isUpdated;
	}// end of updateUser()

	@Override
	public TransactionBean doTransaction(@RequestBody TransBean transBean) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = null;
		TransactionBean bean = new TransactionBean();

		UserTrackerBean bean1 = manager.find(UserTrackerBean.class, transBean.getFromAccountId());
		UserTrackerBean bean2 = manager.find(UserTrackerBean.class, transBean.getToAccountId());
		if (bean1 != null && bean2 != null) {
			if (bean1.getAccountBalance() > transBean.getAmount()) {
				bean1.setAccountBalance(bean1.getAccountBalance() - transBean.getAmount());
				bean2.setAccountBalance(bean2.getAccountBalance() + transBean.getAmount());

				bean.setAccountId(bean1.getAccountId());
				bean.setDateOfTransaction(new Date());
				bean.setTranAmount(transBean.getAmount());
				bean.setPayeeAccountId(bean2.getAccountId());
				bean.setTransactionType("Online Mode");
				bean.setTranDescription("Transfer Amount");

				try {
					tx = manager.getTransaction();
					tx.begin();
					manager.persist(bean);
					tx.commit();
				} catch (Exception e) {
					throw new BMSException("Please check the account Id's Properly");
				}
				manager.close();
			} else {
			throw new BMSException("You dont have enough amount to transfer");
		}
		}else {
			throw new BMSException("Please check the account Id's Properly");
		}
 
		return bean;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionBean> getAllTransactions(int accountId) {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from TransactionBean where accountId=:accountid";
		Query query = manager.createQuery(jpql);
		query.setParameter("accountid", accountId);

		List<TransactionBean> transList = null;
		try {
			transList = query.getResultList();
		} catch (Exception e) {
			throw new BMSException("Id does not exist");
		}

		return transList;
	}

	@Override
	public boolean checkBookRequest(ServiceTrackerBean serviceTrackerBean) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction ts = manager.getTransaction();
		String jpql = "from UserTrackerBean where accountId=:accountId";
		Query query = manager.createQuery(jpql);
		query.setParameter("accountId", serviceTrackerBean.getAccountId());
		boolean isAdded = false;

		try {
			@SuppressWarnings("unused")
			UserTrackerBean userTrackerBean = new UserTrackerBean();
			userTrackerBean = (UserTrackerBean) query.getSingleResult();
			ts.begin();
			serviceTrackerBean.setServiceRaisedDate(new Date());
			manager.persist(serviceTrackerBean);
			isAdded = true;
			ts.commit();

		} catch (Exception e) {
			throw new BMSException("Unable to send Request. Please check your Id");
		}
		manager.close();

		return isAdded;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ServiceTrackerBean> getAllcheckBookRequest() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from ServiceTrackerBean";
		Query query = manager.createQuery(jpql);
		List<ServiceTrackerBean> checkBookList = null;
		try {
			checkBookList = query.getResultList();
		} catch (Exception e) {
			throw new BMSException("No Checkbook Requests are available");
		}

		return checkBookList;
	}

}
