package com.jfsfeb.bankingsystemspringboot.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.jfsfeb.bankingsystemspringboot.beans.UserResponse;
import com.jfsfeb.bankingsystemspringboot.exception.BMSException;

@RestControllerAdvice
public class BankControllerAdvice {
	
	@ExceptionHandler(BMSException.class)
	public UserResponse handleBMSException(BMSException exception) {
		UserResponse response = new UserResponse();
		response.setDescription(exception.getMessage());
		response.setStatusCode(402);
		response.setMessage("Exception");
		
		return response;
	}
	
	@ExceptionHandler(Exception.class)
	public UserResponse handleException(Exception exception) {
		UserResponse response = new UserResponse();
		response.setDescription(exception.getMessage());
		response.setStatusCode(402);
		response.setMessage("Exception");
		
		return response;
	}

}//end of BankControllerAdvice
