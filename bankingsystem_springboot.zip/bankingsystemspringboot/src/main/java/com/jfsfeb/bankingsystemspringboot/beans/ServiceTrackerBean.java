package com.jfsfeb.bankingsystemspringboot.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="service_tracker")
public class ServiceTrackerBean {
	
	@Id
	@GeneratedValue
	@Column(name="Service_Id")
	private int serviceId;
	
	@Column(name="Service_Raised_Date")
	private Date serviceRaisedDate;
	
	@Column(name="Account_Id")
	private int accountId;

}
