package com.jfsfeb.bankingsystemspringboot.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
//import javax.xml.bind.annotation.XmlElement;

import lombok.Data;

@Data
@Entity
@Table(name = "user_tracker")
public class UserTrackerBean {

	@Id
	@Column(name = "Account_Id")
	private int accountId;

	@Column(name = "Login_Password")
	private String password;

	@Column(name = "User_Type")
	private String userType;
	
	@Column(name="Customer_Name")
	private  String customerName;
	
	@Column(name="Email")
	private String email;
	
	@Column(name="Phone")
	private long phone;
	
	@Column(name="Pan_Card")
	private String panCard;
	
	@Column(name = "Account_Type")
	private String accountType;
	
	@Column(name="Account_Balance")
	private double accountBalance;

}
