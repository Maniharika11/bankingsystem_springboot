package com.jfsfeb.bankingsystemspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingSystemSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingSystemSpringBootApplication.class, args);
	}

}
