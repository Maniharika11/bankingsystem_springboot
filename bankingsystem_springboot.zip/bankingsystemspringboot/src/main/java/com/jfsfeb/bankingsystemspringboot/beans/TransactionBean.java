package com.jfsfeb.bankingsystemspringboot.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="transactions")
public class TransactionBean {
	
	@Column(name="Account_Id")
	private int accountId;
	
	@Id
	@GeneratedValue
	@Column(name="Transaction_Id")
	private int transactionId;

	@Column(name="Tran_Description")
	private String tranDescription;

	@Column(name="Date_Of_Transaction")
	private Date dateOfTransaction;

	@Column(name="Transaction_Type")
	private String transactionType;

	@Column(name="TranAmount")
	private double tranAmount;
	
	@Column(name = "Payee_Account_Id")
	private int payeeAccountId;
	
}
