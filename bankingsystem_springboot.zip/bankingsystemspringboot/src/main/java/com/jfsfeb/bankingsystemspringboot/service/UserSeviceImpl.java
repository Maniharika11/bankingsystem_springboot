package com.jfsfeb.bankingsystemspringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jfsfeb.bankingsystemspringboot.beans.LoginBean;
import com.jfsfeb.bankingsystemspringboot.beans.ServiceTrackerBean;
import com.jfsfeb.bankingsystemspringboot.beans.TransBean;
import com.jfsfeb.bankingsystemspringboot.beans.TransactionBean;
import com.jfsfeb.bankingsystemspringboot.beans.UserTrackerBean;
import com.jfsfeb.bankingsystemspringboot.dao.BankDao;

@Service
public class UserSeviceImpl implements BankService{
	
	@Autowired
	private BankDao dao;
	
	@Override
	public UserTrackerBean login(LoginBean loginBean) {
		return dao.login(loginBean);
	}

	@Override
	public boolean addUser(UserTrackerBean userTrackerBean) {
		return dao.addUser(userTrackerBean);
	}

	@Override
	public List<TransactionBean> getAllTransactions() {
		return dao.getAllTransactions();
	}

	@Override
	public boolean updateUser(UserTrackerBean updateDetail){
		return dao.updateUser(updateDetail);
	}

	@Override
	public TransactionBean doTransaction(TransBean transBean) {
		return dao.doTransaction(transBean);
	}

	@Override
	public List<TransactionBean> getAllTransactions(int accountId) {
		return dao.getAllTransactions(accountId);
	}

	@Override
	public List<UserTrackerBean> getAllDetails() {
		return dao.getAllDetails();
	}

	@Override
	public boolean checkBookRequest(ServiceTrackerBean serviceTrackerBean) {
		 return dao.checkBookRequest(serviceTrackerBean);
	}

	@Override
	public List<ServiceTrackerBean> getAllcheckBookRequest() {
		 return dao.getAllcheckBookRequest();
	}
}
