package com.jfsfeb.bankingsystemspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingSystemSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
