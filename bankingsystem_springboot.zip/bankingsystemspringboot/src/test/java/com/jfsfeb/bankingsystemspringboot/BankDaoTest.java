package com.jfsfeb.bankingsystemspringboot;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.jfsfeb.bankingsystemspringboot.beans.ServiceTrackerBean;
import com.jfsfeb.bankingsystemspringboot.beans.TransBean;
import com.jfsfeb.bankingsystemspringboot.beans.TransactionBean;
import com.jfsfeb.bankingsystemspringboot.beans.UserTrackerBean;
import com.jfsfeb.bankingsystemspringboot.dao.BankDao;
import com.jfsfeb.bankingsystemspringboot.exception.BMSException;

@SpringBootTest
public class BankDaoTest {
	@Autowired
	private BankDao dao;

	@Test
	public void testaddUserTest() {
		UserTrackerBean bean = new UserTrackerBean();
		bean.setAccountId(8765);
		bean.setAccountBalance(10000);
		bean.setEmail("maggi@gmail.com");
		bean.setPhone(9876543210l);
		bean.setPanCard("FTHD567YH8");
		bean.setPassword("Maggi@11");
		bean.setCustomerName("maggi");
		bean.setUserType("user");
		try {
			boolean check = dao.addUser(bean);
			Assertions.assertEquals(check, true);
		} catch (Exception e) {
			Assertions.assertThrows(BMSException.class, () -> {
				dao.addUser(bean);
			});
		}
	}

	@Test
	public void testupdateUserValid() {
		UserTrackerBean bean = new UserTrackerBean();
		bean.setAccountId(8765);
		bean.setPassword("Meghana@11");
		bean.setEmail("meghana@gmail.com");
		bean.setPhone(9876544217l);
		try {
			boolean check = dao.updateUser(bean);
			Assertions.assertEquals(check, true);
		} catch (Exception e) {
			Assertions.assertThrows(BMSException.class, () -> {
				dao.addUser(bean);
			});
		}
	}

	@Test
	public void testcheckBookRequestValid() {
		ServiceTrackerBean bean = new ServiceTrackerBean();
		bean.setAccountId(8765);
		try {
			boolean check = dao.checkBookRequest(bean);
			Assertions.assertEquals(check, true);
		} catch (Exception e) {
			Assertions.assertThrows(BMSException.class, () -> {
				dao.checkBookRequest(bean);
			});
		}
	}

	@Test
	public void testdoTransactionValid() {
		TransBean tbean = new TransBean();
		tbean.setAmount(1000);
		tbean.setFromAccountId(8765);
		tbean.setToAccountId(9876);
		TransactionBean check = dao.doTransaction(tbean);
		Assertions.assertNotNull(check);
	}

	@Test
	public void testgetAllTransactionsInvalid() {
		Assertions.assertNotNull(dao.getAllTransactions(8765));
	}

}